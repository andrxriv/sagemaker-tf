import json
import subprocess
import boto3
import os
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

sm_client = boto3.client('sagemaker')

def lambda_handler(event, context):
    """
    Handle SageMaker CreateUserProfile events from EventBridge
    Creates private EFS directories and updates user profile configurations
    """
    logger.info(f"Received CreateUserProfile event: {json.dumps(event, indent=2)}")
    
    try:
        # Get EFS and Domain ID from environment
        file_system = os.environ['efs_id']
        domain_id = os.environ['domain_id']    
        
        logger.info(f"Processing domain: {domain_id}")
        logger.info(f"Using EFS: {file_system}")
        
        # Get Domain user profiles
        list_user_profiles_response = sm_client.list_user_profiles(
            DomainIdEquals=domain_id
        )
        domain_users = list_user_profiles_response["UserProfiles"]
        
        logger.info(f"Found {len(domain_users)} user profiles in domain")
        
        # Create directories for each user
        for user in domain_users:
            user_profile_name = user["UserProfileName"]
            logger.info(f"Processing user profile: {user_profile_name}")
            
            try:
                # Create user directory with permissions
                repository = f'/mnt/efs/{user_profile_name}'
                logger.info(f"Creating directory: {repository}")
                
                # Create directory
                subprocess.call(['mkdir', '-p', repository])
                
                # Set ownership to SageMaker default UID/GID
                subprocess.call(['chown', '200001:1001', repository])
                
                logger.info(f"Successfully created directory for {user_profile_name}")
                
                # Update SageMaker user profile with custom file system
                response = sm_client.update_user_profile(
                    DomainId=domain_id,
                    UserProfileName=user_profile_name,
                    UserSettings={
                        'CustomFileSystemConfigs': [
                            {
                                'EFSFileSystemConfig': {
                                    'FileSystemId': file_system,
                                    'FileSystemPath': f'/{user_profile_name}'
                                }
                            }
                        ]
                    }
                )
                
                logger.info(f"Successfully updated user profile: {user_profile_name}")
                
            except Exception as user_error:
                logger.error(f"Error processing user {user_profile_name}: {str(user_error)}")
                continue  # Continue with next user if one fails
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Successfully processed {len(domain_users)} user profiles',
                'domain_id': domain_id,
                'file_system': file_system,
                'users_processed': [user["UserProfileName"] for user in domain_users]
            })
        }
        
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
