import json
import subprocess
import boto3
import os
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

sm_client = boto3.client('sagemaker')

def lambda_handler(event, context):
    """
    Handle SageMaker CreateUserProfile events from EventBridge  
    Creates EFS directory for the specific user that was just created
    """
    logger.info(f"Lambda triggered by CreateUserProfile event")
    logger.info(f"Event received: {json.dumps(event, indent=2)}")
    
    try:
        # Get EFS and Domain ID from environment
        file_system = os.environ['efs_id']
        domain_id = os.environ['domain_id']    
        
        logger.info(f"Processing domain: {domain_id}")
        logger.info(f"Using EFS: {file_system}")
        
        # Extract user profile name from the event
        detail = event.get('detail', {})
        request_parameters = detail.get('requestParameters', {})
        user_profile_name = request_parameters.get('userProfileName', '')
        
        if not user_profile_name:
            logger.error("Could not extract user profile name from event requestParameters")
            logger.error(f"Event detail: {json.dumps(detail, indent=2)}")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing user profile name in event requestParameters'})
            }
            
        logger.info(f"Processing newly created user profile: {user_profile_name}")
        
        try:
            # Create user directory with permissions
            repository = f'/mnt/efs/{user_profile_name}'
            logger.info(f"Creating directory: {repository}")
            
            # Create directory (with -p flag for mkdir)
            mkdir_result = subprocess.call(['mkdir', '-p', repository])
            logger.info(f"mkdir result for {user_profile_name}: {mkdir_result}")
            
            # Set ownership to SageMaker default UID/GID
            chown_result = subprocess.call(['chown', '200001:1001', repository])
            logger.info(f"chown result for {user_profile_name}: {chown_result}")
            
            # Update SageMaker user profile
            response = sm_client.update_user_profile(
                DomainId=domain_id,
                UserProfileName=user_profile_name,
                UserSettings={
                    'CustomFileSystemConfigs': [
                        {
                            'EFSFileSystemConfig': {
                                'FileSystemId': file_system,
                                'FileSystemPath': f'/{user_profile_name}'
                            }
                        }
                    ]
                }
            )
            
            logger.info(f"Successfully processed user profile: {user_profile_name}")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': f'Successfully created EFS directory for {user_profile_name}',
                    'domain_id': domain_id,
                    'file_system': file_system,
                    'user_profile': user_profile_name,
                    'efs_directory': f'/{user_profile_name}'
                })
            }
            
        except Exception as user_error:
            logger.error(f"Error processing user {user_profile_name}: {str(user_error)}")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': f'Failed to process user profile: {str(user_error)}',
                    'user_profile': user_profile_name,
                    'domain_id': domain_id
                })
            }
        
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'domain_id': os.environ.get('domain_id', 'unknown'),
                'file_system': os.environ.get('efs_id', 'unknown')
            })
        }
