import json
import boto3
import logging
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    """
    Handle SageMaker CreateUserProfile events from EventBridge
    """
    logger.info(f"Received CreateUserProfile event: {json.dumps(event, indent=2)}")
    
    try:
        # Extract event details
        detail = event.get('detail', {})
        source = event.get('source', '')
        
        if source == 'aws.sagemaker':
            event_name = detail.get('eventName', '')
            
            if event_name == 'CreateUserProfile':
                # Extract user profile information
                user_profile_name = detail.get('responseElements', {}).get('userProfileName', '')
                domain_id = detail.get('responseElements', {}).get('domainId', '')
                
                logger.info(f"CreateUserProfile detected:")
                logger.info(f"  User Profile: {user_profile_name}")
                logger.info(f"  Domain ID: {domain_id}")
                logger.info(f"  Environment: {os.environ.get('ENVIRONMENT', 'unknown')}")
                
                # Add your custom logic here
                # Examples:
                # - Send notification to Slack/Teams
                # - Update database records
                # - Initialize user resources
                # - Set up user-specific configurations
                
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': f'Successfully processed CreateUserProfile for {user_profile_name}',
                        'userProfile': user_profile_name,
                        'domainId': domain_id
                    })
                }
            
    except Exception as e:
        logger.error(f"Error processing event: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Event processed but no action taken'})
    }
